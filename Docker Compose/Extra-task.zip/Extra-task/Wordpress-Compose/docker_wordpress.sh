#! /bin/bash

# Move to directory
cd /home/urveshdomadiya/Documents/Docker\ Compose/Extra-task/Wordpress-Compose/

# Build and Run the docker-compose.yml file
sudo docker-compose up --build -d

