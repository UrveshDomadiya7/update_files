#! /bin/bash

# Move to directory
cd /home/urveshdomadiya/Documents/Docker\ Compose/Extra-task/

# Create react app
npx create-react-app my-react-app 

# move to directory
cd my-react-app

# start execution
npm start


